// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from stsl_interfaces:msg/Tag.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__MSG__DETAIL__TAG__TRAITS_HPP_
#define STSL_INTERFACES__MSG__DETAIL__TAG__TRAITS_HPP_

#include "stsl_interfaces/msg/detail/tag__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::msg::Tag>()
{
  return "stsl_interfaces::msg::Tag";
}

template<>
inline const char * name<stsl_interfaces::msg::Tag>()
{
  return "stsl_interfaces/msg/Tag";
}

template<>
struct has_fixed_size<stsl_interfaces::msg::Tag>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Pose>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::msg::Tag>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Pose>::value> {};

template<>
struct is_message<stsl_interfaces::msg::Tag>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // STSL_INTERFACES__MSG__DETAIL__TAG__TRAITS_HPP_
