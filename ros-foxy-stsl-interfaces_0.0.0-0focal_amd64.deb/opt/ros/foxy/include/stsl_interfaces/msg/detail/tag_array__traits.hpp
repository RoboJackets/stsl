// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from stsl_interfaces:msg/TagArray.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__TRAITS_HPP_
#define STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__TRAITS_HPP_

#include "stsl_interfaces/msg/detail/tag_array__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::msg::TagArray>()
{
  return "stsl_interfaces::msg::TagArray";
}

template<>
inline const char * name<stsl_interfaces::msg::TagArray>()
{
  return "stsl_interfaces/msg/TagArray";
}

template<>
struct has_fixed_size<stsl_interfaces::msg::TagArray>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<stsl_interfaces::msg::TagArray>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<stsl_interfaces::msg::TagArray>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__TRAITS_HPP_
