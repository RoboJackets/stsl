// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from stsl_interfaces:msg/TagArray.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "stsl_interfaces/msg/detail/tag_array__rosidl_typesupport_introspection_c.h"
#include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "stsl_interfaces/msg/detail/tag_array__functions.h"
#include "stsl_interfaces/msg/detail/tag_array__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `tags`
#include "stsl_interfaces/msg/tag.h"
// Member `tags`
#include "stsl_interfaces/msg/detail/tag__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void TagArray__rosidl_typesupport_introspection_c__TagArray_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__msg__TagArray__init(message_memory);
}

void TagArray__rosidl_typesupport_introspection_c__TagArray_fini_function(void * message_memory)
{
  stsl_interfaces__msg__TagArray__fini(message_memory);
}

size_t TagArray__rosidl_typesupport_introspection_c__size_function__Tag__tags(
  const void * untyped_member)
{
  const stsl_interfaces__msg__Tag__Sequence * member =
    (const stsl_interfaces__msg__Tag__Sequence *)(untyped_member);
  return member->size;
}

const void * TagArray__rosidl_typesupport_introspection_c__get_const_function__Tag__tags(
  const void * untyped_member, size_t index)
{
  const stsl_interfaces__msg__Tag__Sequence * member =
    (const stsl_interfaces__msg__Tag__Sequence *)(untyped_member);
  return &member->data[index];
}

void * TagArray__rosidl_typesupport_introspection_c__get_function__Tag__tags(
  void * untyped_member, size_t index)
{
  stsl_interfaces__msg__Tag__Sequence * member =
    (stsl_interfaces__msg__Tag__Sequence *)(untyped_member);
  return &member->data[index];
}

bool TagArray__rosidl_typesupport_introspection_c__resize_function__Tag__tags(
  void * untyped_member, size_t size)
{
  stsl_interfaces__msg__Tag__Sequence * member =
    (stsl_interfaces__msg__Tag__Sequence *)(untyped_member);
  stsl_interfaces__msg__Tag__Sequence__fini(member);
  return stsl_interfaces__msg__Tag__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember TagArray__rosidl_typesupport_introspection_c__TagArray_message_member_array[2] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__msg__TagArray, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "tags",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__msg__TagArray, tags),  // bytes offset in struct
    NULL,  // default value
    TagArray__rosidl_typesupport_introspection_c__size_function__Tag__tags,  // size() function pointer
    TagArray__rosidl_typesupport_introspection_c__get_const_function__Tag__tags,  // get_const(index) function pointer
    TagArray__rosidl_typesupport_introspection_c__get_function__Tag__tags,  // get(index) function pointer
    TagArray__rosidl_typesupport_introspection_c__resize_function__Tag__tags  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers TagArray__rosidl_typesupport_introspection_c__TagArray_message_members = {
  "stsl_interfaces__msg",  // message namespace
  "TagArray",  // message name
  2,  // number of fields
  sizeof(stsl_interfaces__msg__TagArray),
  TagArray__rosidl_typesupport_introspection_c__TagArray_message_member_array,  // message members
  TagArray__rosidl_typesupport_introspection_c__TagArray_init_function,  // function to initialize message memory (memory has to be allocated)
  TagArray__rosidl_typesupport_introspection_c__TagArray_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t TagArray__rosidl_typesupport_introspection_c__TagArray_message_type_support_handle = {
  0,
  &TagArray__rosidl_typesupport_introspection_c__TagArray_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, msg, TagArray)() {
  TagArray__rosidl_typesupport_introspection_c__TagArray_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  TagArray__rosidl_typesupport_introspection_c__TagArray_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, msg, Tag)();
  if (!TagArray__rosidl_typesupport_introspection_c__TagArray_message_type_support_handle.typesupport_identifier) {
    TagArray__rosidl_typesupport_introspection_c__TagArray_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &TagArray__rosidl_typesupport_introspection_c__TagArray_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
