// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from stsl_interfaces:msg/Tag.idl
// generated code does not contain a copyright notice
#include "stsl_interfaces/msg/detail/tag__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/detail/pose__functions.h"

bool
stsl_interfaces__msg__Tag__init(stsl_interfaces__msg__Tag * msg)
{
  if (!msg) {
    return false;
  }
  // id
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    stsl_interfaces__msg__Tag__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__msg__Tag__fini(stsl_interfaces__msg__Tag * msg)
{
  if (!msg) {
    return;
  }
  // id
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
}

stsl_interfaces__msg__Tag *
stsl_interfaces__msg__Tag__create()
{
  stsl_interfaces__msg__Tag * msg = (stsl_interfaces__msg__Tag *)malloc(sizeof(stsl_interfaces__msg__Tag));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__msg__Tag));
  bool success = stsl_interfaces__msg__Tag__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__msg__Tag__destroy(stsl_interfaces__msg__Tag * msg)
{
  if (msg) {
    stsl_interfaces__msg__Tag__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__msg__Tag__Sequence__init(stsl_interfaces__msg__Tag__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__msg__Tag * data = NULL;
  if (size) {
    data = (stsl_interfaces__msg__Tag *)calloc(size, sizeof(stsl_interfaces__msg__Tag));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__msg__Tag__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__msg__Tag__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__msg__Tag__Sequence__fini(stsl_interfaces__msg__Tag__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__msg__Tag__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__msg__Tag__Sequence *
stsl_interfaces__msg__Tag__Sequence__create(size_t size)
{
  stsl_interfaces__msg__Tag__Sequence * array = (stsl_interfaces__msg__Tag__Sequence *)malloc(sizeof(stsl_interfaces__msg__Tag__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__msg__Tag__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__msg__Tag__Sequence__destroy(stsl_interfaces__msg__Tag__Sequence * array)
{
  if (array) {
    stsl_interfaces__msg__Tag__Sequence__fini(array);
  }
  free(array);
}
