// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from stsl_interfaces:msg/TagArray.idl
// generated code does not contain a copyright notice
#ifndef STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "stsl_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_stsl_interfaces
size_t get_serialized_size_stsl_interfaces__msg__TagArray(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_stsl_interfaces
size_t max_serialized_size_stsl_interfaces__msg__TagArray(
  bool & full_bounded,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, stsl_interfaces, msg, TagArray)();

#ifdef __cplusplus
}
#endif

#endif  // STSL_INTERFACES__MSG__DETAIL__TAG_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
