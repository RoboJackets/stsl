// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from stsl_interfaces:msg/TagArray.idl
// generated code does not contain a copyright notice
#include "stsl_interfaces/msg/detail/tag_array__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `tags`
#include "stsl_interfaces/msg/detail/tag__functions.h"

bool
stsl_interfaces__msg__TagArray__init(stsl_interfaces__msg__TagArray * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    stsl_interfaces__msg__TagArray__fini(msg);
    return false;
  }
  // tags
  if (!stsl_interfaces__msg__Tag__Sequence__init(&msg->tags, 0)) {
    stsl_interfaces__msg__TagArray__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__msg__TagArray__fini(stsl_interfaces__msg__TagArray * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // tags
  stsl_interfaces__msg__Tag__Sequence__fini(&msg->tags);
}

stsl_interfaces__msg__TagArray *
stsl_interfaces__msg__TagArray__create()
{
  stsl_interfaces__msg__TagArray * msg = (stsl_interfaces__msg__TagArray *)malloc(sizeof(stsl_interfaces__msg__TagArray));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__msg__TagArray));
  bool success = stsl_interfaces__msg__TagArray__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__msg__TagArray__destroy(stsl_interfaces__msg__TagArray * msg)
{
  if (msg) {
    stsl_interfaces__msg__TagArray__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__msg__TagArray__Sequence__init(stsl_interfaces__msg__TagArray__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__msg__TagArray * data = NULL;
  if (size) {
    data = (stsl_interfaces__msg__TagArray *)calloc(size, sizeof(stsl_interfaces__msg__TagArray));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__msg__TagArray__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__msg__TagArray__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__msg__TagArray__Sequence__fini(stsl_interfaces__msg__TagArray__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__msg__TagArray__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__msg__TagArray__Sequence *
stsl_interfaces__msg__TagArray__Sequence__create(size_t size)
{
  stsl_interfaces__msg__TagArray__Sequence * array = (stsl_interfaces__msg__TagArray__Sequence *)malloc(sizeof(stsl_interfaces__msg__TagArray__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__msg__TagArray__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__msg__TagArray__Sequence__destroy(stsl_interfaces__msg__TagArray__Sequence * array)
{
  if (array) {
    stsl_interfaces__msg__TagArray__Sequence__fini(array);
  }
  free(array);
}
