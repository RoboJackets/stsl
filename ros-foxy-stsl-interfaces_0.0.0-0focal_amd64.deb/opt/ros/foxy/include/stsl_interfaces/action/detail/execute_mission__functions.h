// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from stsl_interfaces:action/ExecuteMission.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__FUNCTIONS_H_
#define STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "stsl_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "stsl_interfaces/action/detail/execute_mission__struct.h"

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_Goal
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_Goal__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Goal__init(stsl_interfaces__action__ExecuteMission_Goal * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Goal__fini(stsl_interfaces__action__ExecuteMission_Goal * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_Goal__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Goal *
stsl_interfaces__action__ExecuteMission_Goal__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Goal__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Goal__destroy(stsl_interfaces__action__ExecuteMission_Goal * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_Goal__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Goal__Sequence__init(stsl_interfaces__action__ExecuteMission_Goal__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Goal__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Goal__Sequence__fini(stsl_interfaces__action__ExecuteMission_Goal__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_Goal__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Goal__Sequence *
stsl_interfaces__action__ExecuteMission_Goal__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Goal__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Goal__Sequence__destroy(stsl_interfaces__action__ExecuteMission_Goal__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_Result
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_Result__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Result__init(stsl_interfaces__action__ExecuteMission_Result * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Result__fini(stsl_interfaces__action__ExecuteMission_Result * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_Result__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Result *
stsl_interfaces__action__ExecuteMission_Result__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Result__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Result__destroy(stsl_interfaces__action__ExecuteMission_Result * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_Result__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Result__Sequence__init(stsl_interfaces__action__ExecuteMission_Result__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Result__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Result__Sequence__fini(stsl_interfaces__action__ExecuteMission_Result__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_Result__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Result__Sequence *
stsl_interfaces__action__ExecuteMission_Result__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Result__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Result__Sequence__destroy(stsl_interfaces__action__ExecuteMission_Result__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_Feedback
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_Feedback__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Feedback__init(stsl_interfaces__action__ExecuteMission_Feedback * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Feedback__fini(stsl_interfaces__action__ExecuteMission_Feedback * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_Feedback__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Feedback *
stsl_interfaces__action__ExecuteMission_Feedback__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Feedback__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Feedback__destroy(stsl_interfaces__action__ExecuteMission_Feedback * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_Feedback__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_Feedback__Sequence__init(stsl_interfaces__action__ExecuteMission_Feedback__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Feedback__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Feedback__Sequence__fini(stsl_interfaces__action__ExecuteMission_Feedback__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_Feedback__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_Feedback__Sequence *
stsl_interfaces__action__ExecuteMission_Feedback__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_Feedback__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_Feedback__Sequence__destroy(stsl_interfaces__action__ExecuteMission_Feedback__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_SendGoal_Request__init(stsl_interfaces__action__ExecuteMission_SendGoal_Request * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Request__fini(stsl_interfaces__action__ExecuteMission_SendGoal_Request * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_SendGoal_Request *
stsl_interfaces__action__ExecuteMission_SendGoal_Request__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Request__destroy(stsl_interfaces__action__ExecuteMission_SendGoal_Request * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__init(stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__fini(stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence *
stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence__destroy(stsl_interfaces__action__ExecuteMission_SendGoal_Request__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_SendGoal_Response__init(stsl_interfaces__action__ExecuteMission_SendGoal_Response * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Response__fini(stsl_interfaces__action__ExecuteMission_SendGoal_Response * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_SendGoal_Response *
stsl_interfaces__action__ExecuteMission_SendGoal_Response__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Response__destroy(stsl_interfaces__action__ExecuteMission_SendGoal_Response * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__init(stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__fini(stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence *
stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence__destroy(stsl_interfaces__action__ExecuteMission_SendGoal_Response__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_GetResult_Request
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_GetResult_Request__init(stsl_interfaces__action__ExecuteMission_GetResult_Request * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Request__fini(stsl_interfaces__action__ExecuteMission_GetResult_Request * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_GetResult_Request *
stsl_interfaces__action__ExecuteMission_GetResult_Request__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Request__destroy(stsl_interfaces__action__ExecuteMission_GetResult_Request * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__init(stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__fini(stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence *
stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence__destroy(stsl_interfaces__action__ExecuteMission_GetResult_Request__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_GetResult_Response
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_GetResult_Response__init(stsl_interfaces__action__ExecuteMission_GetResult_Response * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Response__fini(stsl_interfaces__action__ExecuteMission_GetResult_Response * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_GetResult_Response *
stsl_interfaces__action__ExecuteMission_GetResult_Response__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Response__destroy(stsl_interfaces__action__ExecuteMission_GetResult_Response * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__init(stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__fini(stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence *
stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence__destroy(stsl_interfaces__action__ExecuteMission_GetResult_Response__Sequence * array);

/// Initialize action/ExecuteMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage
 * )) before or use
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_FeedbackMessage__init(stsl_interfaces__action__ExecuteMission_FeedbackMessage * msg);

/// Finalize action/ExecuteMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_FeedbackMessage__fini(stsl_interfaces__action__ExecuteMission_FeedbackMessage * msg);

/// Create action/ExecuteMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_FeedbackMessage *
stsl_interfaces__action__ExecuteMission_FeedbackMessage__create();

/// Destroy action/ExecuteMission message.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_FeedbackMessage__destroy(stsl_interfaces__action__ExecuteMission_FeedbackMessage * msg);


/// Initialize array of action/ExecuteMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
bool
stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__init(stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence * array, size_t size);

/// Finalize array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__fini(stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence * array);

/// Create array of action/ExecuteMission messages.
/**
 * It allocates the memory for the array and calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence *
stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__create(size_t size);

/// Destroy array of action/ExecuteMission messages.
/**
 * It calls
 * stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
void
stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence__destroy(stsl_interfaces__action__ExecuteMission_FeedbackMessage__Sequence * array);

#ifdef __cplusplus
}
#endif

#endif  // STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__FUNCTIONS_H_
