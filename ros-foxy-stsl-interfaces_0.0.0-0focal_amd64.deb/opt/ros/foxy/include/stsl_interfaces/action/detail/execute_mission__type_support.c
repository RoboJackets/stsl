// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from stsl_interfaces:action/ExecuteMission.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
#include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "stsl_interfaces/action/detail/execute_mission__functions.h"
#include "stsl_interfaces/action/detail/execute_mission__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_Goal__init(message_memory);
}

void ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_Goal__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_member_array[1] = {
  {
    "structure_needs_at_least_one_member",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_Goal, structure_needs_at_least_one_member),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_Goal",  // message name
  1,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_Goal),
  ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_member_array,  // message members
  ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_type_support_handle = {
  0,
  &ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Goal)() {
  if (!ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_Goal__rosidl_typesupport_introspection_c__ExecuteMission_Goal_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_Result__init(message_memory);
}

void ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_Result__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_member_array[1] = {
  {
    "structure_needs_at_least_one_member",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_Result, structure_needs_at_least_one_member),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_Result",  // message name
  1,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_Result),
  ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_member_array,  // message members
  ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_type_support_handle = {
  0,
  &ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Result)() {
  if (!ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_Result__rosidl_typesupport_introspection_c__ExecuteMission_Result_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_Feedback__init(message_memory);
}

void ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_Feedback__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_member_array[1] = {
  {
    "structure_needs_at_least_one_member",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_Feedback, structure_needs_at_least_one_member),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_Feedback",  // message name
  1,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_Feedback),
  ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_member_array,  // message members
  ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_type_support_handle = {
  0,
  &ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Feedback)() {
  if (!ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_Feedback__rosidl_typesupport_introspection_c__ExecuteMission_Feedback_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


// Include directives for member types
// Member `goal_id`
#include "unique_identifier_msgs/msg/uuid.h"
// Member `goal_id`
#include "unique_identifier_msgs/msg/detail/uuid__rosidl_typesupport_introspection_c.h"
// Member `goal`
#include "stsl_interfaces/action/execute_mission.h"
// Member `goal`
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_SendGoal_Request__init(message_memory);
}

void ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_SendGoal_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_member_array[2] = {
  {
    "goal_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_SendGoal_Request, goal_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "goal",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_SendGoal_Request, goal),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_SendGoal_Request",  // message name
  2,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_SendGoal_Request),
  ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_member_array,  // message members
  ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_type_support_handle = {
  0,
  &ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Request)() {
  ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, unique_identifier_msgs, msg, UUID)();
  ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Goal)();
  if (!ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_SendGoal_Request__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


// Include directives for member types
// Member `stamp`
#include "builtin_interfaces/msg/time.h"
// Member `stamp`
#include "builtin_interfaces/msg/detail/time__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_SendGoal_Response__init(message_memory);
}

void ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_SendGoal_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_member_array[2] = {
  {
    "accepted",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_SendGoal_Response, accepted),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "stamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_SendGoal_Response, stamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_SendGoal_Response",  // message name
  2,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_SendGoal_Response),
  ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_member_array,  // message members
  ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_type_support_handle = {
  0,
  &ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Response)() {
  ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, builtin_interfaces, msg, Time)();
  if (!ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_SendGoal_Response__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_members = {
  "stsl_interfaces__action",  // service namespace
  "ExecuteMission_SendGoal",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Request_message_type_support_handle,
  NULL  // response message
  // stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_Response_message_type_support_handle
};

static rosidl_service_type_support_t stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_type_support_handle = {
  0,
  &stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal)() {
  if (!stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_type_support_handle.typesupport_identifier) {
    stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_SendGoal_Response)()->data;
  }

  return &stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_SendGoal_service_type_support_handle;
}

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/uuid.h"
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_GetResult_Request__init(message_memory);
}

void ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_GetResult_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_member_array[1] = {
  {
    "goal_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_GetResult_Request, goal_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_GetResult_Request",  // message name
  1,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_GetResult_Request),
  ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_member_array,  // message members
  ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_type_support_handle = {
  0,
  &ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Request)() {
  ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, unique_identifier_msgs, msg, UUID)();
  if (!ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_GetResult_Request__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


// Include directives for member types
// Member `result`
// already included above
// #include "stsl_interfaces/action/execute_mission.h"
// Member `result`
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_GetResult_Response__init(message_memory);
}

void ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_GetResult_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_member_array[2] = {
  {
    "status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_GetResult_Response, status),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "result",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_GetResult_Response, result),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_GetResult_Response",  // message name
  2,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_GetResult_Response),
  ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_member_array,  // message members
  ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_type_support_handle = {
  0,
  &ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Response)() {
  ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Result)();
  if (!ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_GetResult_Response__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_members = {
  "stsl_interfaces__action",  // service namespace
  "ExecuteMission_GetResult",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Request_message_type_support_handle,
  NULL  // response message
  // stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_Response_message_type_support_handle
};

static rosidl_service_type_support_t stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_type_support_handle = {
  0,
  &stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult)() {
  if (!stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_type_support_handle.typesupport_identifier) {
    stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_GetResult_Response)()->data;
  }

  return &stsl_interfaces__action__detail__execute_mission__rosidl_typesupport_introspection_c__ExecuteMission_GetResult_service_type_support_handle;
}

// already included above
// #include <stddef.h>
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"
// already included above
// #include "stsl_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__functions.h"
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__struct.h"


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/uuid.h"
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__rosidl_typesupport_introspection_c.h"
// Member `feedback`
// already included above
// #include "stsl_interfaces/action/execute_mission.h"
// Member `feedback`
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  stsl_interfaces__action__ExecuteMission_FeedbackMessage__init(message_memory);
}

void ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_fini_function(void * message_memory)
{
  stsl_interfaces__action__ExecuteMission_FeedbackMessage__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_member_array[2] = {
  {
    "goal_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_FeedbackMessage, goal_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "feedback",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(stsl_interfaces__action__ExecuteMission_FeedbackMessage, feedback),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_members = {
  "stsl_interfaces__action",  // message namespace
  "ExecuteMission_FeedbackMessage",  // message name
  2,  // number of fields
  sizeof(stsl_interfaces__action__ExecuteMission_FeedbackMessage),
  ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_member_array,  // message members
  ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_init_function,  // function to initialize message memory (memory has to be allocated)
  ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_type_support_handle = {
  0,
  &ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_FeedbackMessage)() {
  ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, unique_identifier_msgs, msg, UUID)();
  ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, stsl_interfaces, action, ExecuteMission_Feedback)();
  if (!ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_type_support_handle.typesupport_identifier) {
    ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ExecuteMission_FeedbackMessage__rosidl_typesupport_introspection_c__ExecuteMission_FeedbackMessage_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
