// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from stsl_interfaces:action/ExecuteMission.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__TRAITS_HPP_
#define STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__TRAITS_HPP_

#include "stsl_interfaces/action/detail/execute_mission__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_Goal>()
{
  return "stsl_interfaces::action::ExecuteMission_Goal";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_Goal>()
{
  return "stsl_interfaces/action/ExecuteMission_Goal";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_Goal>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_Goal>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_Goal>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_Result>()
{
  return "stsl_interfaces::action::ExecuteMission_Result";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_Result>()
{
  return "stsl_interfaces/action/ExecuteMission_Result";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_Result>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_Result>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_Result>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_Feedback>()
{
  return "stsl_interfaces::action::ExecuteMission_Feedback";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_Feedback>()
{
  return "stsl_interfaces/action/ExecuteMission_Feedback";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_Feedback>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_Feedback>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_Feedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'goal'
#include "stsl_interfaces/action/detail/execute_mission__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_SendGoal_Request>()
{
  return "stsl_interfaces::action::ExecuteMission_SendGoal_Request";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_SendGoal_Request>()
{
  return "stsl_interfaces/action/ExecuteMission_SendGoal_Request";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_SendGoal_Request>
  : std::integral_constant<bool, has_fixed_size<stsl_interfaces::action::ExecuteMission_Goal>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_SendGoal_Request>
  : std::integral_constant<bool, has_bounded_size<stsl_interfaces::action::ExecuteMission_Goal>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_SendGoal_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_SendGoal_Response>()
{
  return "stsl_interfaces::action::ExecuteMission_SendGoal_Response";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_SendGoal_Response>()
{
  return "stsl_interfaces/action/ExecuteMission_SendGoal_Response";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_SendGoal_Response>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_SendGoal_Response>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_SendGoal_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_SendGoal>()
{
  return "stsl_interfaces::action::ExecuteMission_SendGoal";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_SendGoal>()
{
  return "stsl_interfaces/action/ExecuteMission_SendGoal";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_SendGoal>
  : std::integral_constant<
    bool,
    has_fixed_size<stsl_interfaces::action::ExecuteMission_SendGoal_Request>::value &&
    has_fixed_size<stsl_interfaces::action::ExecuteMission_SendGoal_Response>::value
  >
{
};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_SendGoal>
  : std::integral_constant<
    bool,
    has_bounded_size<stsl_interfaces::action::ExecuteMission_SendGoal_Request>::value &&
    has_bounded_size<stsl_interfaces::action::ExecuteMission_SendGoal_Response>::value
  >
{
};

template<>
struct is_service<stsl_interfaces::action::ExecuteMission_SendGoal>
  : std::true_type
{
};

template<>
struct is_service_request<stsl_interfaces::action::ExecuteMission_SendGoal_Request>
  : std::true_type
{
};

template<>
struct is_service_response<stsl_interfaces::action::ExecuteMission_SendGoal_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_GetResult_Request>()
{
  return "stsl_interfaces::action::ExecuteMission_GetResult_Request";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_GetResult_Request>()
{
  return "stsl_interfaces/action/ExecuteMission_GetResult_Request";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_GetResult_Request>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_GetResult_Request>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_GetResult_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'result'
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_GetResult_Response>()
{
  return "stsl_interfaces::action::ExecuteMission_GetResult_Response";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_GetResult_Response>()
{
  return "stsl_interfaces/action/ExecuteMission_GetResult_Response";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_GetResult_Response>
  : std::integral_constant<bool, has_fixed_size<stsl_interfaces::action::ExecuteMission_Result>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_GetResult_Response>
  : std::integral_constant<bool, has_bounded_size<stsl_interfaces::action::ExecuteMission_Result>::value> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_GetResult_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_GetResult>()
{
  return "stsl_interfaces::action::ExecuteMission_GetResult";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_GetResult>()
{
  return "stsl_interfaces/action/ExecuteMission_GetResult";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_GetResult>
  : std::integral_constant<
    bool,
    has_fixed_size<stsl_interfaces::action::ExecuteMission_GetResult_Request>::value &&
    has_fixed_size<stsl_interfaces::action::ExecuteMission_GetResult_Response>::value
  >
{
};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_GetResult>
  : std::integral_constant<
    bool,
    has_bounded_size<stsl_interfaces::action::ExecuteMission_GetResult_Request>::value &&
    has_bounded_size<stsl_interfaces::action::ExecuteMission_GetResult_Response>::value
  >
{
};

template<>
struct is_service<stsl_interfaces::action::ExecuteMission_GetResult>
  : std::true_type
{
};

template<>
struct is_service_request<stsl_interfaces::action::ExecuteMission_GetResult_Request>
  : std::true_type
{
};

template<>
struct is_service_response<stsl_interfaces::action::ExecuteMission_GetResult_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'feedback'
// already included above
// #include "stsl_interfaces/action/detail/execute_mission__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::action::ExecuteMission_FeedbackMessage>()
{
  return "stsl_interfaces::action::ExecuteMission_FeedbackMessage";
}

template<>
inline const char * name<stsl_interfaces::action::ExecuteMission_FeedbackMessage>()
{
  return "stsl_interfaces/action/ExecuteMission_FeedbackMessage";
}

template<>
struct has_fixed_size<stsl_interfaces::action::ExecuteMission_FeedbackMessage>
  : std::integral_constant<bool, has_fixed_size<stsl_interfaces::action::ExecuteMission_Feedback>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<stsl_interfaces::action::ExecuteMission_FeedbackMessage>
  : std::integral_constant<bool, has_bounded_size<stsl_interfaces::action::ExecuteMission_Feedback>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<stsl_interfaces::action::ExecuteMission_FeedbackMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits


namespace rosidl_generator_traits
{

template<>
struct is_action<stsl_interfaces::action::ExecuteMission>
  : std::true_type
{
};

template<>
struct is_action_goal<stsl_interfaces::action::ExecuteMission_Goal>
  : std::true_type
{
};

template<>
struct is_action_result<stsl_interfaces::action::ExecuteMission_Result>
  : std::true_type
{
};

template<>
struct is_action_feedback<stsl_interfaces::action::ExecuteMission_Feedback>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits


#endif  // STSL_INTERFACES__ACTION__DETAIL__EXECUTE_MISSION__TRAITS_HPP_
