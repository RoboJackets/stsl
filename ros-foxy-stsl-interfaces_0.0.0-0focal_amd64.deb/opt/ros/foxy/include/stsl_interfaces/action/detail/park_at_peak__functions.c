// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from stsl_interfaces:action/ParkAtPeak.idl
// generated code does not contain a copyright notice
#include "stsl_interfaces/action/detail/park_at_peak__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
stsl_interfaces__action__ParkAtPeak_Goal__init(stsl_interfaces__action__ParkAtPeak_Goal * msg)
{
  if (!msg) {
    return false;
  }
  // structure_needs_at_least_one_member
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Goal__fini(stsl_interfaces__action__ParkAtPeak_Goal * msg)
{
  if (!msg) {
    return;
  }
  // structure_needs_at_least_one_member
}

stsl_interfaces__action__ParkAtPeak_Goal *
stsl_interfaces__action__ParkAtPeak_Goal__create()
{
  stsl_interfaces__action__ParkAtPeak_Goal * msg = (stsl_interfaces__action__ParkAtPeak_Goal *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Goal));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_Goal));
  bool success = stsl_interfaces__action__ParkAtPeak_Goal__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_Goal__destroy(stsl_interfaces__action__ParkAtPeak_Goal * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_Goal__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_Goal__Sequence__init(stsl_interfaces__action__ParkAtPeak_Goal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_Goal * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_Goal *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_Goal));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_Goal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_Goal__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Goal__Sequence__fini(stsl_interfaces__action__ParkAtPeak_Goal__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_Goal__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_Goal__Sequence *
stsl_interfaces__action__ParkAtPeak_Goal__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_Goal__Sequence * array = (stsl_interfaces__action__ParkAtPeak_Goal__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Goal__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_Goal__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_Goal__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_Goal__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_Goal__Sequence__fini(array);
  }
  free(array);
}


bool
stsl_interfaces__action__ParkAtPeak_Result__init(stsl_interfaces__action__ParkAtPeak_Result * msg)
{
  if (!msg) {
    return false;
  }
  // structure_needs_at_least_one_member
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Result__fini(stsl_interfaces__action__ParkAtPeak_Result * msg)
{
  if (!msg) {
    return;
  }
  // structure_needs_at_least_one_member
}

stsl_interfaces__action__ParkAtPeak_Result *
stsl_interfaces__action__ParkAtPeak_Result__create()
{
  stsl_interfaces__action__ParkAtPeak_Result * msg = (stsl_interfaces__action__ParkAtPeak_Result *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Result));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_Result));
  bool success = stsl_interfaces__action__ParkAtPeak_Result__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_Result__destroy(stsl_interfaces__action__ParkAtPeak_Result * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_Result__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_Result__Sequence__init(stsl_interfaces__action__ParkAtPeak_Result__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_Result * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_Result *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_Result));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_Result__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_Result__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Result__Sequence__fini(stsl_interfaces__action__ParkAtPeak_Result__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_Result__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_Result__Sequence *
stsl_interfaces__action__ParkAtPeak_Result__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_Result__Sequence * array = (stsl_interfaces__action__ParkAtPeak_Result__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Result__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_Result__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_Result__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_Result__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_Result__Sequence__fini(array);
  }
  free(array);
}


bool
stsl_interfaces__action__ParkAtPeak_Feedback__init(stsl_interfaces__action__ParkAtPeak_Feedback * msg)
{
  if (!msg) {
    return false;
  }
  // structure_needs_at_least_one_member
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Feedback__fini(stsl_interfaces__action__ParkAtPeak_Feedback * msg)
{
  if (!msg) {
    return;
  }
  // structure_needs_at_least_one_member
}

stsl_interfaces__action__ParkAtPeak_Feedback *
stsl_interfaces__action__ParkAtPeak_Feedback__create()
{
  stsl_interfaces__action__ParkAtPeak_Feedback * msg = (stsl_interfaces__action__ParkAtPeak_Feedback *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Feedback));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_Feedback));
  bool success = stsl_interfaces__action__ParkAtPeak_Feedback__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_Feedback__destroy(stsl_interfaces__action__ParkAtPeak_Feedback * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_Feedback__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__init(stsl_interfaces__action__ParkAtPeak_Feedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_Feedback * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_Feedback *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_Feedback));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_Feedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_Feedback__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__fini(stsl_interfaces__action__ParkAtPeak_Feedback__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_Feedback__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_Feedback__Sequence *
stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_Feedback__Sequence * array = (stsl_interfaces__action__ParkAtPeak_Feedback__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_Feedback__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_Feedback__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_Feedback__Sequence__fini(array);
  }
  free(array);
}


// Include directives for member types
// Member `goal_id`
#include "unique_identifier_msgs/msg/detail/uuid__functions.h"
// Member `goal`
// already included above
// #include "stsl_interfaces/action/detail/park_at_peak__functions.h"

bool
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__init(stsl_interfaces__action__ParkAtPeak_SendGoal_Request * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(msg);
    return false;
  }
  // goal
  if (!stsl_interfaces__action__ParkAtPeak_Goal__init(&msg->goal)) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(stsl_interfaces__action__ParkAtPeak_SendGoal_Request * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
  // goal
  stsl_interfaces__action__ParkAtPeak_Goal__fini(&msg->goal);
}

stsl_interfaces__action__ParkAtPeak_SendGoal_Request *
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__create()
{
  stsl_interfaces__action__ParkAtPeak_SendGoal_Request * msg = (stsl_interfaces__action__ParkAtPeak_SendGoal_Request *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Request));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Request));
  bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Request__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__destroy(stsl_interfaces__action__ParkAtPeak_SendGoal_Request * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__init(stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_SendGoal_Request * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_SendGoal_Request *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Request));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__fini(stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_SendGoal_Request__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence *
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence * array = (stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Request__Sequence__fini(array);
  }
  free(array);
}


// Include directives for member types
// Member `stamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__init(stsl_interfaces__action__ParkAtPeak_SendGoal_Response * msg)
{
  if (!msg) {
    return false;
  }
  // accepted
  // stamp
  if (!builtin_interfaces__msg__Time__init(&msg->stamp)) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Response__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__fini(stsl_interfaces__action__ParkAtPeak_SendGoal_Response * msg)
{
  if (!msg) {
    return;
  }
  // accepted
  // stamp
  builtin_interfaces__msg__Time__fini(&msg->stamp);
}

stsl_interfaces__action__ParkAtPeak_SendGoal_Response *
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__create()
{
  stsl_interfaces__action__ParkAtPeak_SendGoal_Response * msg = (stsl_interfaces__action__ParkAtPeak_SendGoal_Response *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Response));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Response));
  bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Response__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__destroy(stsl_interfaces__action__ParkAtPeak_SendGoal_Response * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Response__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__init(stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_SendGoal_Response * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_SendGoal_Response *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Response));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_SendGoal_Response__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__fini(stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_SendGoal_Response__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence *
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence * array = (stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_SendGoal_Response__Sequence__fini(array);
  }
  free(array);
}


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__functions.h"

bool
stsl_interfaces__action__ParkAtPeak_GetResult_Request__init(stsl_interfaces__action__ParkAtPeak_GetResult_Request * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Request__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Request__fini(stsl_interfaces__action__ParkAtPeak_GetResult_Request * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
}

stsl_interfaces__action__ParkAtPeak_GetResult_Request *
stsl_interfaces__action__ParkAtPeak_GetResult_Request__create()
{
  stsl_interfaces__action__ParkAtPeak_GetResult_Request * msg = (stsl_interfaces__action__ParkAtPeak_GetResult_Request *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Request));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Request));
  bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Request__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Request__destroy(stsl_interfaces__action__ParkAtPeak_GetResult_Request * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Request__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__init(stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_GetResult_Request * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_GetResult_Request *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Request));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_GetResult_Request__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__fini(stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_GetResult_Request__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence *
stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence * array = (stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Request__Sequence__fini(array);
  }
  free(array);
}


// Include directives for member types
// Member `result`
// already included above
// #include "stsl_interfaces/action/detail/park_at_peak__functions.h"

bool
stsl_interfaces__action__ParkAtPeak_GetResult_Response__init(stsl_interfaces__action__ParkAtPeak_GetResult_Response * msg)
{
  if (!msg) {
    return false;
  }
  // status
  // result
  if (!stsl_interfaces__action__ParkAtPeak_Result__init(&msg->result)) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Response__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Response__fini(stsl_interfaces__action__ParkAtPeak_GetResult_Response * msg)
{
  if (!msg) {
    return;
  }
  // status
  // result
  stsl_interfaces__action__ParkAtPeak_Result__fini(&msg->result);
}

stsl_interfaces__action__ParkAtPeak_GetResult_Response *
stsl_interfaces__action__ParkAtPeak_GetResult_Response__create()
{
  stsl_interfaces__action__ParkAtPeak_GetResult_Response * msg = (stsl_interfaces__action__ParkAtPeak_GetResult_Response *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Response));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Response));
  bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Response__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Response__destroy(stsl_interfaces__action__ParkAtPeak_GetResult_Response * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Response__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__init(stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_GetResult_Response * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_GetResult_Response *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Response));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_GetResult_Response__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__fini(stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_GetResult_Response__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence *
stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence * array = (stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_GetResult_Response__Sequence__fini(array);
  }
  free(array);
}


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__functions.h"
// Member `feedback`
// already included above
// #include "stsl_interfaces/action/detail/park_at_peak__functions.h"

bool
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__init(stsl_interfaces__action__ParkAtPeak_FeedbackMessage * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(msg);
    return false;
  }
  // feedback
  if (!stsl_interfaces__action__ParkAtPeak_Feedback__init(&msg->feedback)) {
    stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(msg);
    return false;
  }
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(stsl_interfaces__action__ParkAtPeak_FeedbackMessage * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
  // feedback
  stsl_interfaces__action__ParkAtPeak_Feedback__fini(&msg->feedback);
}

stsl_interfaces__action__ParkAtPeak_FeedbackMessage *
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__create()
{
  stsl_interfaces__action__ParkAtPeak_FeedbackMessage * msg = (stsl_interfaces__action__ParkAtPeak_FeedbackMessage *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_FeedbackMessage));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__action__ParkAtPeak_FeedbackMessage));
  bool success = stsl_interfaces__action__ParkAtPeak_FeedbackMessage__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__destroy(stsl_interfaces__action__ParkAtPeak_FeedbackMessage * msg)
{
  if (msg) {
    stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__init(stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__action__ParkAtPeak_FeedbackMessage * data = NULL;
  if (size) {
    data = (stsl_interfaces__action__ParkAtPeak_FeedbackMessage *)calloc(size, sizeof(stsl_interfaces__action__ParkAtPeak_FeedbackMessage));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__action__ParkAtPeak_FeedbackMessage__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__fini(stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__action__ParkAtPeak_FeedbackMessage__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence *
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__create(size_t size)
{
  stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence * array = (stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence *)malloc(sizeof(stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__destroy(stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence * array)
{
  if (array) {
    stsl_interfaces__action__ParkAtPeak_FeedbackMessage__Sequence__fini(array);
  }
  free(array);
}
