// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from stsl_interfaces:srv/SampleElevation.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TRAITS_HPP_
#define STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TRAITS_HPP_

#include "stsl_interfaces/srv/detail/sample_elevation__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::srv::SampleElevation_Request>()
{
  return "stsl_interfaces::srv::SampleElevation_Request";
}

template<>
inline const char * name<stsl_interfaces::srv::SampleElevation_Request>()
{
  return "stsl_interfaces/srv/SampleElevation_Request";
}

template<>
struct has_fixed_size<stsl_interfaces::srv::SampleElevation_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<stsl_interfaces::srv::SampleElevation_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<stsl_interfaces::srv::SampleElevation_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::srv::SampleElevation_Response>()
{
  return "stsl_interfaces::srv::SampleElevation_Response";
}

template<>
inline const char * name<stsl_interfaces::srv::SampleElevation_Response>()
{
  return "stsl_interfaces/srv/SampleElevation_Response";
}

template<>
struct has_fixed_size<stsl_interfaces::srv::SampleElevation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<stsl_interfaces::srv::SampleElevation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<stsl_interfaces::srv::SampleElevation_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<stsl_interfaces::srv::SampleElevation>()
{
  return "stsl_interfaces::srv::SampleElevation";
}

template<>
inline const char * name<stsl_interfaces::srv::SampleElevation>()
{
  return "stsl_interfaces/srv/SampleElevation";
}

template<>
struct has_fixed_size<stsl_interfaces::srv::SampleElevation>
  : std::integral_constant<
    bool,
    has_fixed_size<stsl_interfaces::srv::SampleElevation_Request>::value &&
    has_fixed_size<stsl_interfaces::srv::SampleElevation_Response>::value
  >
{
};

template<>
struct has_bounded_size<stsl_interfaces::srv::SampleElevation>
  : std::integral_constant<
    bool,
    has_bounded_size<stsl_interfaces::srv::SampleElevation_Request>::value &&
    has_bounded_size<stsl_interfaces::srv::SampleElevation_Response>::value
  >
{
};

template<>
struct is_service<stsl_interfaces::srv::SampleElevation>
  : std::true_type
{
};

template<>
struct is_service_request<stsl_interfaces::srv::SampleElevation_Request>
  : std::true_type
{
};

template<>
struct is_service_response<stsl_interfaces::srv::SampleElevation_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TRAITS_HPP_
