// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from stsl_interfaces:srv/SampleElevation.idl
// generated code does not contain a copyright notice

#ifndef STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TYPE_SUPPORT_H_
#define STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "stsl_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  stsl_interfaces,
  srv,
  SampleElevation_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  stsl_interfaces,
  srv,
  SampleElevation_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_stsl_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  stsl_interfaces,
  srv,
  SampleElevation
)();

#ifdef __cplusplus
}
#endif

#endif  // STSL_INTERFACES__SRV__DETAIL__SAMPLE_ELEVATION__TYPE_SUPPORT_H_
