// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from stsl_interfaces:srv/SampleElevation.idl
// generated code does not contain a copyright notice
#include "stsl_interfaces/srv/detail/sample_elevation__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

bool
stsl_interfaces__srv__SampleElevation_Request__init(stsl_interfaces__srv__SampleElevation_Request * msg)
{
  if (!msg) {
    return false;
  }
  // x
  // y
  return true;
}

void
stsl_interfaces__srv__SampleElevation_Request__fini(stsl_interfaces__srv__SampleElevation_Request * msg)
{
  if (!msg) {
    return;
  }
  // x
  // y
}

stsl_interfaces__srv__SampleElevation_Request *
stsl_interfaces__srv__SampleElevation_Request__create()
{
  stsl_interfaces__srv__SampleElevation_Request * msg = (stsl_interfaces__srv__SampleElevation_Request *)malloc(sizeof(stsl_interfaces__srv__SampleElevation_Request));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__srv__SampleElevation_Request));
  bool success = stsl_interfaces__srv__SampleElevation_Request__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__srv__SampleElevation_Request__destroy(stsl_interfaces__srv__SampleElevation_Request * msg)
{
  if (msg) {
    stsl_interfaces__srv__SampleElevation_Request__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__srv__SampleElevation_Request__Sequence__init(stsl_interfaces__srv__SampleElevation_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__srv__SampleElevation_Request * data = NULL;
  if (size) {
    data = (stsl_interfaces__srv__SampleElevation_Request *)calloc(size, sizeof(stsl_interfaces__srv__SampleElevation_Request));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__srv__SampleElevation_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__srv__SampleElevation_Request__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__srv__SampleElevation_Request__Sequence__fini(stsl_interfaces__srv__SampleElevation_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__srv__SampleElevation_Request__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__srv__SampleElevation_Request__Sequence *
stsl_interfaces__srv__SampleElevation_Request__Sequence__create(size_t size)
{
  stsl_interfaces__srv__SampleElevation_Request__Sequence * array = (stsl_interfaces__srv__SampleElevation_Request__Sequence *)malloc(sizeof(stsl_interfaces__srv__SampleElevation_Request__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__srv__SampleElevation_Request__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__srv__SampleElevation_Request__Sequence__destroy(stsl_interfaces__srv__SampleElevation_Request__Sequence * array)
{
  if (array) {
    stsl_interfaces__srv__SampleElevation_Request__Sequence__fini(array);
  }
  free(array);
}


bool
stsl_interfaces__srv__SampleElevation_Response__init(stsl_interfaces__srv__SampleElevation_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // elevation
  return true;
}

void
stsl_interfaces__srv__SampleElevation_Response__fini(stsl_interfaces__srv__SampleElevation_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // elevation
}

stsl_interfaces__srv__SampleElevation_Response *
stsl_interfaces__srv__SampleElevation_Response__create()
{
  stsl_interfaces__srv__SampleElevation_Response * msg = (stsl_interfaces__srv__SampleElevation_Response *)malloc(sizeof(stsl_interfaces__srv__SampleElevation_Response));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(stsl_interfaces__srv__SampleElevation_Response));
  bool success = stsl_interfaces__srv__SampleElevation_Response__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
stsl_interfaces__srv__SampleElevation_Response__destroy(stsl_interfaces__srv__SampleElevation_Response * msg)
{
  if (msg) {
    stsl_interfaces__srv__SampleElevation_Response__fini(msg);
  }
  free(msg);
}


bool
stsl_interfaces__srv__SampleElevation_Response__Sequence__init(stsl_interfaces__srv__SampleElevation_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  stsl_interfaces__srv__SampleElevation_Response * data = NULL;
  if (size) {
    data = (stsl_interfaces__srv__SampleElevation_Response *)calloc(size, sizeof(stsl_interfaces__srv__SampleElevation_Response));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = stsl_interfaces__srv__SampleElevation_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        stsl_interfaces__srv__SampleElevation_Response__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
stsl_interfaces__srv__SampleElevation_Response__Sequence__fini(stsl_interfaces__srv__SampleElevation_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      stsl_interfaces__srv__SampleElevation_Response__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

stsl_interfaces__srv__SampleElevation_Response__Sequence *
stsl_interfaces__srv__SampleElevation_Response__Sequence__create(size_t size)
{
  stsl_interfaces__srv__SampleElevation_Response__Sequence * array = (stsl_interfaces__srv__SampleElevation_Response__Sequence *)malloc(sizeof(stsl_interfaces__srv__SampleElevation_Response__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = stsl_interfaces__srv__SampleElevation_Response__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
stsl_interfaces__srv__SampleElevation_Response__Sequence__destroy(stsl_interfaces__srv__SampleElevation_Response__Sequence * array)
{
  if (array) {
    stsl_interfaces__srv__SampleElevation_Response__Sequence__fini(array);
  }
  free(array);
}
