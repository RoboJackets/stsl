#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "aruco_tag_model_generation::tag_model_generator" for configuration "None"
set_property(TARGET aruco_tag_model_generation::tag_model_generator APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(aruco_tag_model_generation::tag_model_generator PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aruco_tag_model_generation/tag_model_generator"
  )

list(APPEND _IMPORT_CHECK_TARGETS aruco_tag_model_generation::tag_model_generator )
list(APPEND _IMPORT_CHECK_FILES_FOR_aruco_tag_model_generation::tag_model_generator "${_IMPORT_PREFIX}/lib/aruco_tag_model_generation/tag_model_generator" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
